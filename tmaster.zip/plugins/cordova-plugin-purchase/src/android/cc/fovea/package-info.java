/**
 * Classes used by the cordova-purchase-plugin for Android. 
 *
 * @since 9.0
 * @author jchoelt
 */
package cc.fovea;
