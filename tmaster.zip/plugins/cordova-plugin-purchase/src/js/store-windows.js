// #include "copyright.js"
// #include "store.js"
// #include "platforms/plugin-bridge.js"
// #include "platforms/plugin-adapter.js"
// #include "platforms/windows-productdata.js"

if (window) {
    window.store = store;
}

module.exports = store;
