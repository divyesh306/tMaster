
# !!! PLEASE USE IN SUBJECT [IOS] OR [ANDROID] AS PREFIX FOR YOUR ISSUE !!!

### system info

Please report your OS, OS version, Compiling System and Version, used Plugin Version and any helpful information that can help us to resolve the problem.

In example:
```
OSX Sierra 10.12.04
Cordova 7.0.1 // Phone Gap 3.19.2 etc.
Device: iPhone iOS 10.3.2 // Android 7.1
Plugin Version: 6.0.0
```

### Expected behavior

### Observed behavior

### Steps to reproduce
