# Licenses

## Android version

Apache 2.0

## iOS version

MIT

## Windows version

Apache 2.0
